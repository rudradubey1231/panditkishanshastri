import { motion } from "framer-motion";
import { LucideIcon, Star, Moon, Sun, Sparkles, Heart, Zap } from "lucide-react";
import { type Service } from "@shared/schema";

// Map icon strings to actual components
const iconMap: Record<string, LucideIcon> = {
  Moon,
  Sun,
  Star,
  Sparkles,
  Heart,
  Zap,
};

interface ServiceCardProps {
  service: Service;
  index: number;
}

export function ServiceCard({ service, index }: ServiceCardProps) {
  const Icon = iconMap[service.icon] || Sparkles;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -5 }}
      className="glass-card p-6 rounded-2xl relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl -mr-16 -mt-16 transition-all group-hover:bg-primary/10" />
      
      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-secondary/50 flex items-center justify-center mb-6 border border-primary/20 group-hover:border-primary/50 transition-colors">
        <Icon className="w-6 h-6 text-primary" />
      </div>

      <h3 className="text-xl font-heading font-bold mb-3 text-foreground group-hover:text-primary transition-colors">
        {service.title}
      </h3>
      
      <p className="text-muted-foreground mb-6 line-clamp-3">
        {service.description}
      </p>

      <div className="flex items-center justify-between mt-auto">
        <span className="text-lg font-semibold text-primary">
         {service.price}
        </span>
        <button className="text-sm font-medium text-foreground/80 hover:text-primary flex items-center gap-1 transition-colors">
          Learn More <Sparkles className="w-3 h-3" />
        </button>
      </div>
    </motion.div>
  );
}
