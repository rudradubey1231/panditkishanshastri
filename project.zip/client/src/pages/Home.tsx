import { Navigation } from "@/components/Navigation";
import { ServiceCard } from "@/components/ServiceCard";
import { ContactForm } from "@/components/ContactForm";
import { useServices, useTestimonials } from "@/hooks/use-astrology";
import { motion } from "framer-motion";
import { Star, Moon, Sun, ArrowRight, Quote, Phone, Mail, MapPin, Instagram, Facebook, Youtube } from "lucide-react";
import { Button } from "@/components/ui/button";
import kishaJiImg from "@assets/kisha_ji.jpg_1771727893568.jpeg";
import qrCodeImg from "@assets/godaan-qr.png_1771731278375_1771998234663.jpeg";

// Static content for fallback if DB is empty
const STATIC_SERVICES = [
  { id: 1, title: "Kundli Reading", description: "Detailed analysis of your birth chart to understand your life path, strengths, and challenges.", icon: "Star", price: "₹499" },
  { id: 2, title: "Match Making", description: "Comprehensive compatibility analysis for marriage based on Guna Milan and planetary positions.", icon: "Heart", price: "₹299" },
  { id: 3, title: "Gemstone Therapy", description: "Personalized gemstone recommendations to balance planetary energies and bring good fortune.", icon: "Sparkles", price: "₹499" },
];

export default function Home() {
  const { data: services, isLoading: servicesLoading } = useServices();
  const { data: testimonials, isLoading: testimonialsLoading } = useTestimonials();
  
  const displayServices = services?.length ? services : STATIC_SERVICES;

  return (
    <div className="min-h-screen bg-background text-foreground font-body overflow-x-hidden">
      <Navigation />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-stars opacity-50" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-secondary/40 rounded-full blur-[80px]" />

        <div className="container mx-auto px-4 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6">
              <Star className="w-4 h-4 text-primary" fill="currentColor" />
              <span className="text-sm font-medium tracking-wide">Expert Vedic Astrology Services</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-heading font-bold mb-6 leading-tight">
              Unlock Your <br />
              <span className="text-gradient-gold">Cosmic Potential</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Pandit Kishan Shastri brings over 20 years of experience in Vedic astrology to help you navigate life's journey with clarity and confidence.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                size="lg" 
                className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg h-14 px-8 rounded-full shadow-lg shadow-primary/25"
              >
                Book Consultation
              </Button>
              <Button 
                onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
                size="lg" 
                variant="outline" 
                className="border-white/20 bg-white/5 hover:bg-white/10 text-white text-lg h-14 px-8 rounded-full"
              >
                Explore Services
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="relative hidden lg:block"
          >
            <div className="relative z-10 w-full h-[600px] flex items-center justify-center">
               {/* Replace with actual image of Astrologer */}
               {/* Unsplash image of mystical hands/cosmos */}
               {/* html comment: mystical astrology zodiac chart */}
               <img 
                 src="https://images.unsplash.com/photo-1532968961962-8a0cb3a2d4f5?w=800&auto=format&fit=crop&q=80" 
                 alt="Mystical Zodiac Chart" 
                 className="rounded-full w-[500px] h-[500px] object-cover border-8 border-white/5 shadow-2xl animate-[spin_60s_linear_infinite]"
               />
               <div className="absolute inset-0 flex items-center justify-center">
                 <div className="w-[520px] h-[520px] rounded-full border border-primary/20 animate-pulse" />
                 <div className="absolute w-[600px] h-[600px] rounded-full border border-dashed border-white/10 animate-[spin_40s_linear_infinite_reverse]" />
               </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-secondary/10 relative">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative rounded-2xl overflow-hidden shadow-2xl"
            >
              <img 
                src={kishaJiImg} 
                alt="Pandit Kishan Shastri" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
              <div className="absolute bottom-0 left-0 p-8">
                <h3 className="text-3xl font-heading text-primary">Pandit Kishan Shastri</h3>
                <p className="text-white/80">Vedic Astrologer & Gemologist</p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-heading font-bold mb-6">
                Guiding You Through <br />
                <span className="text-primary">Ancient Wisdom</span>
              </h2>
              <div className="space-y-4 text-lg text-muted-foreground">
                <p>
                  Welcome to a space where ancient wisdom meets modern life challenges. Radhe Radhe, I am Pandit Kishan Shastri, dedicated to helping individuals find purpose, clarity, and peace through the sacred science of Jyotish (Vedic Astrology).
                </p>
                <p>
                  With precise calculations and intuitive insight, I offer guidance on career, relationships, health, and spiritual growth. My approach is practical, remedial, and deeply rooted in the Vedic tradition.
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-6 mt-8">
                <div className="flex flex-col gap-2 p-4 bg-background/50 rounded-xl border border-white/5">
                  <span className="text-4xl font-bold text-primary">20+</span>
                  <span className="text-sm font-medium uppercase tracking-wider opacity-70">Years Experience</span>
                </div>
                <div className="flex flex-col gap-2 p-4 bg-background/50 rounded-xl border border-white/5">
                  <span className="text-4xl font-bold text-primary">5000+</span>
                  <span className="text-sm font-medium uppercase tracking-wider opacity-70">Happy Clients</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 relative">
        <div className="absolute inset-0 bg-stars opacity-30" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-primary font-medium tracking-widest uppercase mb-2 block">Our Offerings</span>
            <h2 className="text-4xl md:text-5xl font-heading font-bold mb-4">Divine Services</h2>
            <p className="text-muted-foreground">Comprehensive astrological solutions tailored to your unique birth chart and life circumstances.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {servicesLoading ? (
              [1, 2, 3].map((i) => (
                <div key={i} className="h-64 rounded-2xl bg-white/5 animate-pulse" />
              ))
            ) : (
              displayServices.map((service, index) => (
                <ServiceCard key={service.id} service={service} index={index} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-gradient-to-b from-background to-secondary/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-heading font-bold mb-4">Client Stories</h2>
            <div className="w-24 h-1 bg-primary mx-auto rounded-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials?.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-background border border-white/5 p-8 rounded-2xl relative"
              >
                <Quote className="absolute top-6 right-6 w-8 h-8 text-primary/20" />
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-4 h-4 ${i < t.rating ? "text-primary fill-primary" : "text-gray-600"}`} 
                    />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6 italic">"{t.content}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-primary to-orange-500 flex items-center justify-center font-bold text-background">
                    {t.name.charAt(0)}
                  </div>
                  <span className="font-semibold">{t.name}</span>
                </div>
              </motion.div>
            )) || (
              <div className="col-span-full text-center text-muted-foreground">
                No testimonials yet.
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] -mr-32 -mt-32" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
            <div>
              <span className="text-primary font-medium tracking-widest uppercase mb-2 block">Get in Touch</span>
              <h2 className="text-4xl md:text-5xl font-heading font-bold mb-8">Start Your Journey</h2>
              <p className="text-lg text-muted-foreground mb-12">
                Have questions or ready to book a reading? Reach out to us directly or fill out the form. Pandit Ji is available for both online and in-person consultations.
              </p>

              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Phone</h4>
                    <p className="text-muted-foreground">+91 9958429287</p>
                    <p className="text-sm text-muted-foreground">(Available 9 AM - 7 PM)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Email</h4>
                    <p className="text-muted-foreground">kishanshukla0308@gamil.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold mb-1">Location</h4>
                    <p className="text-muted-foreground">Mathura, Uttar Pradesh, India</p>
                  </div>
                </div>
              </div>

              <div className="fixed bottom-6 left-6 z-[9999]">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-3 rounded-xl shadow-2xl border border-primary/20"
                >
                  <img
                    src={qrCodeImg}
                    alt="Donation QR"
                    className="w-32 h-32 object-contain"
                  />
                  <p className="text-[10px] text-black text-center mt-2 font-bold uppercase tracking-tight">
                    Gaudaan ke liye Scan karein
                  </p>
                </motion.div>
              </div>
            </div>

            <div className="relative">
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-background border-t border-white/5">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
             <Star className="w-5 h-5 text-primary" fill="currentColor" />
             <span className="font-heading font-bold text-xl">Pandit Kishan Shastri</span>
          </div>
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} All rights reserved. Designed with cosmic intent.
          </p>
        </div>
      </footer>
    </div>
  );
}
