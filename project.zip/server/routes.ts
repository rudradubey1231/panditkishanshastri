import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { db } from "./db";
import { services, testimonials } from "@shared/schema";

async function seedDatabase() {
  const existingServices = await storage.getServices();
  if (existingServices.length === 0) {
    await db.insert(services).values([
      { title: "Vedic Horoscope (kundli)", description: "Detailed reading of your birth chart to uncover life patterns and future predictions.", icon: "Star", price: "₹499" },
      { title: "Matchmaking (Kundali Milan)", description: "Assess compatibility with your prospective partner based on traditional Vedic principles.", icon: "Heart", price: "₹299" },
      { title: "Vastu Consultation", description: "Optimize your home or workspace to harmonize with natural energies.", icon: "Home", price: "₹499" },
      { title: "Gemstone Recommendation", description: "Find the right precious stones to balance planetary influences.", icon: "Gem", price: "₹499" },
    ]);
  }

  const existingTestimonials = await storage.getTestimonials();
  if (existingTestimonials.length === 0) {
    await db.insert(testimonials).values([
      { name: "Rahul S.", content: "Pandit Kishan Shastri's readings were incredibly accurate and helped me make a major career decision.", rating: 5 },
      { name: "Priya M.", content: "The matchmaking consultation gave us peace of mind before our wedding. Highly recommend his deep knowledge.", rating: 5 },
      { name: "Amit K.", content: "His Vastu tips transformed the energy in my new office. Things have been thriving since then!", rating: 4 },
    ]);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Seed DB on startup
  seedDatabase().catch(console.error);

  app.get(api.services.list.path, async (req, res) => {
    const data = await storage.getServices();
    res.json(data);
  });

  app.get(api.testimonials.list.path, async (req, res) => {
    const data = await storage.getTestimonials();
    res.json(data);
  });

  app.post(api.contacts.create.path, async (req, res) => {
    try {
      const input = api.contacts.create.input.parse(req.body);
      await storage.createContact(input);
      res.status(201).json({ success: true });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
